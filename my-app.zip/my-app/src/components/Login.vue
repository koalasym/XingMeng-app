<template>
  <div id="tot_body">
      <div id="top_container">
          <div class="mytitle font_set">登陆</div>
          <div id="input_box">
              <span id="register" class="font_set">未注册的手机验证后将自动注册</span>
              <br/>
              <span id="mobile">+86</span>
              <input id="accountid" class="input_box mobile_input" type="text" placeholder="中国大陆手机号">
              <input id="password" class="input_box" type="password" placeholder="请输入密码">
              <button class="input_button" @click='login' >登陆</button>
              <div id="quick_login">本机号码一键登陆</div>
          </div>
          <div id="tip_box">错误</div>
      </div>
      <div id="bottom_container">
          <ul id="mysocial">
              <li><svg t="1641461168898" class="login_icon" viewBox="0 0 1025 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="1658" width="200" height="200"><path d="M1024.16 694.816c0-149.92-143.104-271.392-319.584-271.392-176.576 0-319.68 121.504-319.68 271.392S528 966.208 704.576 966.208c55.456 0 107.648-12.096 153.184-33.248l125.984 54.528-14.592-140.544c34.784-43.392 55.04-95.808 55.04-152.128zM596.832 621.28c-25.152 0-45.472-20.352-45.472-45.472s20.32-45.472 45.472-45.472c25.12 0 45.44 20.384 45.44 45.472s-20.384 45.472-45.44 45.472z m215.392 0c-25.056 0-45.44-20.352-45.44-45.472s20.384-45.472 45.44-45.472c25.184 0 45.536 20.384 45.536 45.472s-20.352 45.472-45.536 45.472zM704.576 387.488c49.376 0 96.416 8.8 139.264 24.64 0.32-5.728 0.992-11.232 0.992-16.992 0-198.08-189.152-358.624-422.432-358.624C189.184 36.512 0.032 197.024 0.032 395.136c0 74.496 26.816 143.776 72.704 201.12L53.472 781.92l166.432-72.096c41.216 19.2 86.784 32.16 134.88 38.784-3.616-17.504-5.824-35.424-5.824-53.792 0.032-169.44 159.552-307.296 355.616-307.296z m-139.808-209.6c33.184 0 60 26.88 60 60 0 33.184-26.816 60.064-60 60.064s-60.032-26.88-60.032-60.064c0-33.152 26.88-60 60.032-60zM280.032 297.952c-33.184 0-60-26.88-60-60.064 0-33.152 26.848-60 60-60 33.184 0 60.032 26.88 60.032 60s-26.88 60.064-60.032 60.064z" fill="#51C332" p-id="1659"></path></svg></li>
              <li><svg t="1641461216602" class="login_icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="1811" width="200" height="200"><path d="M511.037 986.94c-85.502 0-163.986-26.686-214.517-66.544-25.66 7.149-58.486 18.655-79.202 32.921-17.725 12.202-15.516 24.647-12.32 29.67 14.027 22.069 240.622 14.092 306.04 7.219v-3.265z" fill="#FAAD08" p-id="1812"></path><path d="M495.627 986.94c85.501 0 163.986-26.686 214.518-66.544 25.66 7.149 58.485 18.655 79.203 32.921 17.724 12.202 15.512 24.647 12.32 29.67-14.027 22.069-240.623 14.092-306.042 7.219v-3.265z" fill="#FAAD08" p-id="1813"></path><path d="M496.137 472.026c140.73-0.935 253.514-27.502 291.73-37.696 9.11-2.432 13.984-6.789 13.984-6.789 0.032-1.25 0.578-22.348 0.578-33.232 0-183.287-88.695-367.458-306.812-367.47C277.5 26.851 188.8 211.021 188.8 394.31c0 10.884 0.55 31.982 0.583 33.232 0 0 3.965 4.076 11.231 6.048 35.283 9.579 150.19 37.482 294.485 38.437h1.037z m387.364 154.941c-8.66-27.825-20.484-60.273-32.455-91.434 0 0-6.886-0.848-10.366 0.158-107.424 31.152-237.624 51.006-336.845 49.808h-1.026c-98.664 1.186-227.982-18.44-335.044-49.288-4.09-1.176-12.168-0.677-12.168-0.677-11.97 31.16-23.793 63.608-32.453 91.433-41.3 132.679-27.92 187.587-17.731 188.818 21.862 2.638 85.099-99.88 85.099-99.88 0 104.17 94.212 264.125 309.947 265.596a765.877 765.877 0 0 1 5.725 0c215.738-1.471 309.947-161.424 309.947-265.595 0 0 63.236 102.519 85.102 99.88 10.186-1.231 23.566-56.14-17.732-188.819" p-id="1814"></path><path d="M429.208 303.911c-29.76 1.323-55.195-32.113-56.79-74.62-1.618-42.535 21.183-78.087 50.95-79.417 29.732-1.305 55.149 32.116 56.765 74.64 1.629 42.535-21.177 78.08-50.925 79.397m220.448-74.62c-1.593 42.507-27.03 75.941-56.79 74.62-29.746-1.32-52.553-36.862-50.924-79.397 1.614-42.526 27.03-75.948 56.764-74.639 29.77 1.33 52.57 36.881 50.951 79.417" fill="#FFFFFF" p-id="1815"></path><path d="M695.405 359.069c-7.81-18.783-86.466-39.709-183.843-39.709h-1.045c-97.376 0-176.033 20.926-183.842 39.709a6.66 6.66 0 0 0-0.57 2.672c0 1.353 0.418 2.575 1.072 3.612 6.58 10.416 93.924 61.885 183.341 61.885h1.045c89.416 0 176.758-51.466 183.34-61.883a6.775 6.775 0 0 0 1.069-3.622 6.66 6.66 0 0 0-0.567-2.664" fill="#FAAD08" p-id="1816"></path><path d="M464.674 239.335c1.344 16.946-7.87 32-20.55 33.645-12.701 1.647-24.074-10.755-25.426-27.71-1.326-16.954 7.873-32.008 20.534-33.64 12.722-1.652 24.114 10.76 25.442 27.705m77.97 8.464c2.702-4.392 21.149-27.488 59.328-19.078 10.028 2.208 14.667 5.457 15.646 6.737 1.445 1.888 1.84 4.576 0.375 8.196-2.903 7.174-8.894 6.979-12.217 5.575-2.144-0.907-28.736-16.948-53.232 6.99-1.685 1.648-4.7 2.212-7.558 0.258-2.856-1.956-4.038-5.923-2.342-8.678" p-id="1817"></path><path d="M503.821 589.328h-1.031c-67.806 0.802-150.022-8.004-229.638-23.381-6.817 38.68-10.934 87.294-7.399 145.275 8.928 146.543 97.728 238.652 234.793 239.996h5.57c137.065-1.344 225.865-93.453 234.796-239.996 3.535-57.986-0.584-106.6-7.403-145.283-79.631 15.385-161.861 24.196-229.688 23.389" fill="#FFFFFF" p-id="1818"></path><path d="M310.693 581.35v146.633s69.287 13.552 138.7 4.17V596.897c-43.974-2.413-91.4-7.79-138.7-15.546" fill="#EB1C26" p-id="1819"></path><path d="M806.504 427.238s-130.112 43.08-302.66 44.309h-1.025c-172.264-1.224-302.217-44.161-302.66-44.309L156.58 541.321c108.998 34.464 244.093 56.677 346.238 55.387l1.024-0.002c102.152 1.297 237.226-20.917 346.24-55.385l-43.579-114.083z" fill="#EB1C26" p-id="1820"></path></svg></li>
              <li><svg t="1641461285192" class="login_icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="1970" width="200" height="200"><path d="M510.872 0.00004A511.738935 511.738935 0 0 0 0.578065 470.68598l274.473965 113.377986a144.332982 144.332982 0 0 1 89.621989-24.903997L486.810003 382.552991v-2.615999a193.084975 193.084975 0 1 1 193.049976 193.095975h-4.48L501.388001 697.214951c0 2.275 0.193 4.549999 0.193 6.823a144.799982 144.799982 0 0 1-286.766963 28.543996L18.227063 651.159957A511.965935 511.965935 0 1 0 510.792 0.00004h0.069zM321.404024 776.591941L258.540032 750.549945a108.772986 108.772986 0 1 0 59.599993-148.745981l64.967991 26.837996a80.09299 80.09299 0 1 1-61.646992 147.835981v0.114z m487.139938-396.767949A128.661984 128.661984 0 1 0 679.882979 508.439975a128.843984 128.843984 0 0 0 128.662983-128.616983z m-225.061971-0.228a96.661988 96.661988 0 1 1 96.661988 96.661988 96.433988 96.433988 0 0 1-96.661988-96.661988z" fill="#004986" p-id="1971"></path></svg></li>
          </ul>
          <div id="allow"><input type="checkbox" id="myselect"> 同意星梦《服务协议》和《隐私政策》</div>
      </div>
      <svg @click="back" t="1641465354621" id="back_button" class="login_icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="1859" width="200" height="200"><path d="M511.333 127.333c51.868 0 102.15 10.144 149.451 30.15 45.719 19.337 86.792 47.034 122.078 82.321 35.287 35.286 62.983 76.359 82.321 122.078 20.006 47.3 30.15 97.583 30.15 149.451s-10.144 102.15-30.15 149.451c-19.337 45.719-47.034 86.792-82.321 122.078-35.286 35.287-76.359 62.983-122.078 82.321-47.3 20.006-97.583 30.15-149.451 30.15s-102.15-10.144-149.451-30.15c-45.719-19.337-86.792-47.034-122.078-82.321-35.287-35.286-62.983-76.359-82.321-122.078-20.006-47.3-30.15-97.583-30.15-149.451s10.144-102.15 30.15-149.451c19.337-45.719 47.034-86.792 82.321-122.078 35.286-35.287 76.359-62.983 122.078-82.321 47.301-20.006 97.583-30.15 149.451-30.15m0-64c-247.424 0-448 200.576-448 448s200.576 448 448 448 448-200.576 448-448-200.576-448-448-448z" fill="" p-id="1860"></path><path d="M557.254 512l147.373-147.373c12.497-12.497 12.497-32.758 0-45.255-12.496-12.497-32.758-12.497-45.254 0L512 466.746 364.627 319.373c-12.497-12.497-32.758-12.497-45.255 0s-12.497 32.758 0 45.255L466.746 512 319.373 659.373c-12.497 12.496-12.497 32.758 0 45.254C325.621 710.876 333.811 714 342 714s16.379-3.124 22.627-9.373L512 557.254l147.373 147.373C665.621 710.876 673.811 714 682 714s16.379-3.124 22.627-9.373c12.497-12.496 12.497-32.758 0-45.254L557.254 512z" fill="" p-id="1861"></path></svg>
  </div>
</template>
<script>
export default {
  name: 'Login',
  data(){
      return{
          mydata:null,
          myuserdata:{
            'accountid':null,
            'password':null,
            'address':'中国',
            'post':'0',
            'username':'新用户',
            'follow':'0',
            'fans':'0',
            'avatar':'https://img1.baidu.com/it/u=4130912472,3543066426&fm=26&fmt=auto', 
          }
      }
  },
  methods:{
      back(){
          this.$router.go(-1);
      },
      getData(){
          this.$http({
              url:'http://127.0.0.1:8088/myDemos/testconnection',
              method:'get',
              params:{'type':2}
          }).then(result=>{
              this.mydata = result.data;
          })
      },
      login(){
          var accountid = document.getElementById("accountid").value;
          var psd = document.getElementById("password").value;
          var mytipbox = document.getElementById("tip_box");
          if(accountid==''){
              mytipbox.innerHTML='用户名不可为空';
              this.slide();
          }else if(psd==''){
              mytipbox.innerHTML='密码不可为空';
              this.slide();
          }else{
              var flag=0;
              for(var i=0;i<this.mydata.length;i++){
                  if(this.mydata[i].accountid==accountid&&this.mydata[i].password==psd){
                      this.myuserdata=this.mydata[i];
                      flag = 1;
                      break;
                  }else if(this.mydata[i].accountid==accountid&&this.mydata[i].password!=psd){
                      flag = 2;
                      break;
                  }
                  
              }
              if(flag==0){
                  mytipbox.innerHTML="正在为您注册账号！";
                  mytipbox.style.backgroundColor='green';
                  this.slide();
                  this.myuserdata.accountid=accountid;
                  this.myuserdata.password=psd;
                  this.register();
                  setTimeout(()=>{
                      this.$router.go(-1);
                  },3000);
              }
              if(flag==1){
                  mytipbox.innerHTML="登陆成功！";
                  mytipbox.style.backgroundColor='green';
                  this.slide();
                  var myuser = JSON.stringify(this.myuserdata);
                  window.localStorage.setItem('myuser',myuser);
                  setTimeout(()=>{
                      this.$router.go(-1);
                  },3000);
              }
              if(flag==2){
                  mytipbox.innerHTML="密码错误";
                  document.getElementById("password").value='';
                  this.slide();
              }
          }
      },
      slide(){
          var slidepart = document.getElementById("tip_box");
          slidepart.style.top='40px';
          setTimeout(()=>{
              slidepart.style.top='-100px';
          },2000)
      },
      register(){
          this.$http({
              url:'http://127.0.0.1:8088/myDemos/testconnection',
              method:'get',
              params:this.myuserdata
          });
          var myuser = JSON.stringify(this.myuserdata);
          window.localStorage.setItem('myuser',myuser);
      }
  },
  mounted(){
      this.getData()
  }
}
</script>
<style scoped>
#tot_body
{
    height: 100%;
    width: 100vw;
}
.mytitle
{
    margin-left: 5%;
    margin-top: 40px;
}
.font_set
{
    font-family: "濑户字体简体";
    font-size: 35px;
    font-weight: bold;
}
#top_container
{
    position: absolute;
    width: 100%;
    height: 80%;
}
#input_box
{
    position: absolute;
    width: 100%;
    top: 20%;
}
#register
{
    font-size: 15px;
    font-weight: normal;
    opacity: 50%;
    margin-left: 10%;
}
.input_box
{
    width: 80%;
    margin-left: 8%;
    height: 45px;
    margin-top: 20px;
    font-family: "濑户字体简体";
    border-radius: 25px;
    font-size: 18px;
    padding-left: 15px;
    background: rgb(243, 243, 243);
    border: none;
}
.input_button
{
    width: 85%;
    margin-left: 8%;
    height: 45px;
    margin-top: 20px;
    font-family: "濑户字体简体";
    border-radius: 25px;
    font-size: 22px;
    background: #4A00E0;
    border:none;
    color: white;
    letter-spacing: 10px;
}
.mobile_input
{
    padding-left: 60px;
    width: 69%;
}
#mobile
{
    font-family: "濑户字体简体";
    position: absolute;
    top: 22%;
    left: 14%;
}
#quick_login
{
    font-size: 15px;
    font-family: "濑户字体简体";
    width: 80%;
    margin-left: 10%;
    margin-top: 5%;
    opacity: 75%;
}
.login_icon
{
    width: 25px;
    height: 25px;
}
#mysocial
{
    position: absolute;
    top: 60%;
    display: flex;
    list-style: none;
    width: 50%;
    margin-left: 25%;
    justify-content: space-around;
}
#bottom_container
{
    position: absolute;
    top: 60%;
    width: 100%;
    height: 40%;
}
#allow
{
    position: absolute;
    top: 75%;
    font-size: 15px;
    font-family: "濑户字体简体";
    display: flex;
    align-items: center;
    width: 100%;
    justify-content: center;
}
#myselect
{
    border-radius: 25px;
    width: 15px;
    height: 15px;
}
#back_button
{
    position: absolute;
    right:25px;
    top: 25px;
    width: 30px;
    height: 30px;
    fill: rgb(158, 158, 158);
}
#tip_box
{
    background: rgb(255, 0, 0);
    width: 40%;
    margin-left: 30%;
    text-align: center;
    height: 50px;
    line-height: 50px;
    border-radius: 5px;
    font-size: 18px;
    color: white;
    font-family: "濑户字体简体";
    position: absolute;
    top: -100px;
    transition: 0.8s ease-in-out;
}
</style>
