<template>
    <div>
       <div class='playlist_show_button' id="playlist_show_button" @click="show_change">
           <img id='show_img' :src=playurl />
       </div>
       <div class='play_list' id="my_list" v-show='show'>
           <div id="collocation_container"><img id="mycollocation" src="@/assets/mp3/collocation.png">收藏全部</div>
           <div id="dustbin_container" @click="clearAll"><img id="mydustbin" src="@/assets/mp3/clear.png">清除所有</div>
           <div v-for="(item,index) in list" :key="index" class="detail_list">
               <div @click="change_song(item.data.id)">
                    <img :src='item.data.src' class="song_cover"><div style="margin-left:5%;position:relative;bottom:48px;left:40px;">{{item.data.title}}</div>
                    <div style="margin-left:5%;position:relative;bottom:88px;left:120px;font-size:10px;">-{{item.data.Nname}}</div>
               </div>
               <img class="play_list_delete" src='@/assets/mp3/close.png' @click="delete_song(item)">
               <hr class="list_line"/>
            </div>
            <div id="myplay_panel">
                <div id="play_song_cover_bg">
                    <img id="play_song_cover" :src=playsource.src>
                    <span id="now_play">正在播放  {{playsource.title}}</span>
                    <svg @click="add_to_mylike" t="1640350057680" id="like_icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="4095" width="200" height="200"><path d="M669.781333 130.752c71.637333-11.093333 138.901333 11.477333 193.344 64.533333 55.317333 53.930667 81.834667 124.992 74.282667 199.530667-7.466667 73.642667-46.549333 146.368-112.32 210.474667-18.346667 17.898667-67.669333 66.218667-138.453333 135.637333-31.829333 31.232-65.706667 64.448-99.84 97.984L553.6 871.466667l-13.184 12.949333a40.554667 40.554667 0 0 1-56.832 0l-114.602667-112.64-24.213333-23.722667a677626.346667 677626.346667 0 0 0-145.856-142.762666C133.141333 541.184 94.08 468.48 86.613333 394.816c-7.552-74.538667 18.944-145.6 74.282667-199.530667 54.442667-53.056 121.706667-75.605333 193.344-64.533333 53.162667 8.213333 107.093333 34.688 157.781333 76.949333 50.709333-42.24 104.618667-68.736 157.781334-76.949333z" fill="#ffffff" p-id="4096" data-spm-anchor-id="a313x.7781069.0.i24" class="selected"></path></svg>
                    <img id="my_play_button" @click="song_play" :src=playstate>
                    <div id="play_line">
                        <img id="play_line_img" src="@/assets/mp3/zhangyuge.gif">
                    </div>
                </div>

                <audio id="myaudio" :src='require("../assets/songs/"+playsource.mp3or4)'> 
                    <source  type="audio/mpeg"/>
                </audio>
            </div>
       </div>
    </div>
</template>
<script>
import {mapState} from 'vuex'
export default {
    name:'Playlist',
    data(){
        return{
            show:false,
            playstate:require('../assets/mp3/song_play.png'),
            playurl:require('../assets/mp3/playlist.png'),
            likestate:false,
            timer:null,
        }
    },
    methods:{
        show_change(){
            if(!this.show){
                this.show=true;
                setTimeout(()=>{
                     document.getElementById("my_list").style.height='400px';
                     document.getElementById("playlist_show_button").style.top='45%';
                     document.getElementById("playlist_show_button").style.border='1px solid white';
                     document.getElementById("myplay_panel").style.opacity="100%";

                     var img=document.getElementById("play_line_img");
                     var song = document.getElementById("myaudio");
                     var tot_time = Math.round(song.duration);
                     var curr_time = Math.round(song.currentTime);
                     if(curr_time!=0&&!song.paused&&this.list!=''){
                        img.style.left=(curr_time/tot_time*200-12)+'px';
                        this.line_run();
                     }
                     this.playurl=require('@/assets/mp3/close.png');
                },100)
            }
            else{
                setTimeout(()=>{
                    this.show=false;
                },800)
                window.clearInterval(this.timer);
                document.getElementById("my_list").style.height='0px';
                document.getElementById("playlist_show_button").style.top='75%';
                document.getElementById("playlist_show_button").style.border='1px solid #707070';
                document.getElementById("myplay_panel").style.opacity="0%";
                this.playurl=require('@/assets/mp3/playlist.png');
            }
        },
        song_play(){
            var song = document.getElementById("myaudio");

            if(song.paused){
                this.playstate=require('@/assets/mp3/song_stop.png');
                song.play();      
                this.line_run();    
                this.$store.commit('playlist/setPlaystate',1);
            } 
            else{
                this.playstate=require('@/assets/mp3/song_play.png');
                song.pause();
                window.clearInterval(this.timer);
                this.timer=null;
                this.$store.commit('playlist/setPlaystate',0);
            }
            return this.song_playstate;
        },
        add_to_mylike(){
            var mystate = document.getElementById("like_icon").children[0];
            if(this.likestate){
                mystate.style.fill="white"
                this.likestate=false;

            }else{
                mystate.style.fill="red"
                this.likestate=true;
            }
        },
        line_run(){
            var song = document.getElementById("myaudio");
            var tot_time = Math.round(song.duration);
            var dur_part=tot_time/200;
            if(dur_part<0.8){
                dur_part=0.8;
            }
            var img=document.getElementById("play_line_img");
            this.timer=window.setInterval(()=>{
                    var cur_X_pos=img.offsetLeft;
                    img.style.left=cur_X_pos+dur_part+'px';
                    if(song.ended){
                        img.style.left='-12px';
                        window.clearInterval(this.timer);
                        this.timer=null;
                        this.$store.commit('playlist/deleteList');
                        if(this.list==''){this.show_change()}
                        else{
                        this.$store.commit('playlist/changeSong',this.list[0].data.id);
                        }
                        setTimeout(()=>{
                            this.song_play();
                        },100);
                        this.playstate=require('@/assets/mp3/song_play.png');
                    }
            },2000)
        },
        change_song(data){
            this.song_play();
            this.$store.commit('playlist/changeSong',data);
            if(this.song_state){
                var img=document.getElementById("play_line_img");
                img.style.left='-12px';
                this.$store.commit('playlist/setPlaystate',0);
            }else{
                this.song_play();
            }
            setTimeout(()=>{
                this.song_play();
            },100);
        },
        clearAll(){
            this.$store.commit('playlist/clearallList');
            if(this.myplaystate){
                this.$store.commit('playlist/setPlaystate',0);
                this.song_play();
                var img=document.getElementById("play_line_img");
                img.style.left='-12px';
            }
            this.show_change();
        },
        delete_song(data){
            this.$store.commit('playlist/delete_song',data);
            if(this.myplaystate){
                this.$store.commit('playlist/setPlaystate',0);
                this.song_play();
                var img=document.getElementById("play_line_img");
                img.style.left='-12px';
            }
            if(this.list!=''){
                setTimeout(()=>{
                    this.song_play();
                },100);
            }
        }
    },
    computed:mapState({
        list:state=>state.playlist.list,
        playsource:state=>state.playlist.playsource,
        myplaystate:state=>state.playlist.playstate,
        song_state:state=>state.playlist.song_state,
    }),
}
</script>
<style scoped>
    .playlist_show_button
    {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        position:fixed;
        right: 5%;
        top:75%;
        border: solid 1px #707070;
        transition: 0.5s ease-in-out;
        line-height: 30px;
        text-align: center;
        z-index: 1;
    }
    #show_img
    {
        position: relative;
        top: 5px;
        width: 20px;
        height: 20px;
        transition: 0.5s ease-in-out;
    }
    .play_list
    {
        height:400px;
        width: 100%;
        position: fixed;
        bottom: 0px;
        background: rgb(99, 99, 99);
        opacity: 75%;
        border-top-left-radius: 25px;
        border-top-right-radius:25px;
        transition: 0.8s ease-in-out;
        animation:myshow 0.5s ease-in-out;
    }
    .detail_list
    {
        font-size: 15px;
        color: white;
        height: 10%;
        width: 80%;
        margin-left: 10%;
        margin-top: 15px;
        float: left;
        line-height: 40px;
    }
    .play_list_delete
    {
        width:20px;
        height: 20px;
        position: relative;
        left: 295px;
        bottom:122px;
    }
    .myaudio
    {
        background: white;
        width: 20px;
        height: 20px;
    }
    #myplay_panel
    {
        position: absolute;
        bottom: 0px;
        left: 0px;
        width: 100%;
        height: 50px;
        opacity: 75%;
        background: black;
        transition: 0.8s ease-in-out;
        opacity: 50%;
        border-top-left-radius:25px;
        border-top-right-radius:25px;
    }
    #play_song_cover
    {
        width: 45px;
        height: 45px;
        border-radius: 50%;
        margin-top:5px;
    }
    #play_song_cover_bg
    {
        width: 55px;
        height: 55px;
        border-radius: 50%;
        text-align: center;
        background: rgb(92, 92, 92);
        position: relative;
        top:-15px;
        left: 15px;
    }
    .song_cover
    {
        margin-top:5px;
        width: 30px;
        height: 30px;
        border-radius: 50%;
        margin-left: 10px;
    }
    #my_play_button
    {
        width: 30px;
        height: 30px;
        position: relative;
        top: -30px;
        left: 325px;
    }
    #now_play
    {
        position: absolute;
        top: 20px;
        left: 75px;
        font-size: 12px;
        width: 100px;
        color: white;
    }
    #like_icon
    {
        position: absolute;
        top: 24px;
        left: 300px;
        width: 32px;
        height: 32px;
    }
    #play_line
    {
        position: absolute;
        top:50px;
        left: 75px;
        width: 220px;
        height: 1px;
        border: solid 1px white;
        border-radius: 5px;
        background-color: white;
    }
    #play_line_img
    {
        position: absolute;
        top:-15px;
        left: -12px;
        width: 25px;
        height: 25px;
    }
    .my_enter_animation
    {
        animation:myshow 0.5s ease-in-out;
        animation-fill-mode: forwards;
    }
    .my_leave_animation
    {
        animation:mydis_show 0.5s ease-in-out;
        animation-fill-mode: forwards;
    }
    .list_line
    {
        position: relative;
        top:-125px;
        width:80%;
    }
    #dustbin_container,#collocation_container
    {
        margin:15px 0 0 15px;
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 30%;
        border: solid 1px white;
        border-radius: 25px;
        line-height: 30px;
        font-size: 15px;
        float: left;
    }
    #mycollocation,#mydustbin
    {
        width: 22px;
        height: 22px;
        margin-right: 2px;
    }
    @keyframes myshow {
        0%{
            height: 0px;
        };
        25%{
            height: 150px;
        };
        50%{
            height: 350px;
        };
        75%{
            height: 380px;
        };
        100%{
            height: 400px;
        }
    }
    @keyframes mydis_show {
        0%{
            height: 400px;
        };
        25%{
            height: 380px;
        };
        50%{
            height: 350px;
        };
        75%{
            height: 150px;
        };
        100%{
            height: 0px;
        }
    }
</style>