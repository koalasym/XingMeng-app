<template>
    <div class='contain_box' id='mycontain_box'>
        <router-link v-for="(wtf_img,index) in waterfall_imgs" :to="'/detail/'+(index+1)" tag="div" class='imgbox'  :key="index" :id='"imgbox"+index'>
                <img :src=wtf_img.src class='waterfall_img' :id='"wtf_img"+index'>
                <span class='mytitle'>{{wtf_img.title}}</span>
                <span class='like_share'>
                    <svg t="1636810668294" class="water_icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="6074" width="200" height="200"><path d="M365.604792 262.10044l127.792525-127.793548 0.152473 503.227196c0.004093 11.014868 8.934486 19.943215 19.949354 19.943215 0.002047 0 0.004093 0 0.00614 0 11.016915-0.004093 19.947308-8.937556 19.943215-19.954471l-0.152473-503.100306 127.675868 127.676891c3.89675 3.89675 8.999978 5.843078 14.106276 5.843078 5.104251 0 10.212596-1.948375 14.106276-5.842055 7.79043-7.79043 7.79043-20.422122 0-28.212552L527.85306 72.555479c-3.638877-3.870144-8.791224-6.300496-14.521738-6.300496-0.002047 0-0.004093 0-0.00614 0-0.00614 0-0.01228 0.001023-0.01842 0.001023-0.00614 0-0.01228-0.001023-0.01842-0.001023-5.291516 0-10.364045 2.101871-14.106276 5.842055L337.39224 233.886865c-7.789407 7.79043-7.789407 20.422122 0 28.212552C345.18267 269.89087 357.814362 269.89087 365.604792 262.10044z" p-id="6075"></path><path d="M782.507924 315.087235 642.713041 315.087235c-11.016915 0-19.949354 8.931416-19.949354 19.949354s8.93244 19.949354 19.949354 19.949354l139.794883 0c38.498826 0 69.821205 31.322379 69.821205 69.821205l0 425.443645c0 38.498826-31.322379 69.821205-69.821205 69.821205L246.009973 920.071999c-38.498826 0-69.821205-31.322379-69.821205-69.821205L176.188768 424.806125c0-38.498826 31.322379-69.821205 69.821205-69.821205l143.936203 0c11.017938 0 19.949354-8.931416 19.949354-19.949354s-8.931416-19.949354-19.949354-19.949354L246.009973 315.086212c-60.499909 0-109.718891 49.220005-109.718891 109.718891l0 425.443645c0 60.499909 49.220005 109.718891 109.718891 109.718891l536.49795 0c60.499909 0 109.718891-49.220005 109.718891-109.718891L892.226814 424.806125C892.227838 364.306216 843.007833 315.087235 782.507924 315.087235z" p-id="6076"></path></svg><span class='fontSize'>{{wtf_img.share}}</span>
                    <svg t="1636810714283" class="water_icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="7060" width="200" height="200"><path d="M885.9 533.7c16.8-22.2 26.1-49.4 26.1-77.7 0-44.9-25.1-87.4-65.5-111.1a67.67 67.67 0 0 0-34.3-9.3H572.4l6-122.9c1.4-29.7-9.1-57.9-29.5-79.4-20.5-21.5-48.1-33.4-77.9-33.4-52 0-98 35-111.8 85.1l-85.9 311H144c-17.7 0-32 14.3-32 32v364c0 17.7 14.3 32 32 32h601.3c9.2 0 18.2-1.8 26.5-5.4 47.6-20.3 78.3-66.8 78.3-118.4 0-12.6-1.8-25-5.4-37 16.8-22.2 26.1-49.4 26.1-77.7 0-12.6-1.8-25-5.4-37 16.8-22.2 26.1-49.4 26.1-77.7-0.2-12.6-2-25.1-5.6-37.1zM184 852V568h81v284h-81z m636.4-353l-21.9 19 13.9 25.4c4.6 8.4 6.9 17.6 6.9 27.3 0 16.5-7.2 32.2-19.6 43l-21.9 19 13.9 25.4c4.6 8.4 6.9 17.6 6.9 27.3 0 16.5-7.2 32.2-19.6 43l-21.9 19 13.9 25.4c4.6 8.4 6.9 17.6 6.9 27.3 0 22.4-13.2 42.6-33.6 51.8H329V564.8l99.5-360.5c5.2-18.9 22.5-32.2 42.2-32.3 7.6 0 15.1 2.2 21.1 6.7 9.9 7.4 15.2 18.6 14.6 30.5l-9.6 198.4h314.4C829 418.5 840 436.9 840 456c0 16.5-7.2 32.1-19.6 43z" p-id="7061"></path></svg><span class='fontSize'>{{wtf_img.mylike}}</span>
                </span>
                <img :src=wtf_img.avatar class='myavatar'>
                <span class='Nname'>{{wtf_img.Nname}}</span>
                <span class='Star'>{{wtf_img.Star}}</span>
        </router-link>
    </div>
</template>
<script>
export default{
    name:'waterfall',
    data(){
        return{
            wtf_img:null,
            flag:false
        }
    },
    methods:{
        /*waterfall(img_id){
            console.log(img_id);
            var img=document.getElementById(img_id);
            var imgWidth = 160;
            var imgHeight = parseInt(img.naturalHeight/parseInt(img.naturalWidth/imgWidth))+'px';
            img.style.width=imgWidth;
            img.style.height=imgHeight;
        }*/
        /*依据页面宽度来确定所需列数，之后填充完第一列后，依据高度来确定下一个板块的摆放位置 */
        changeP(){
            var clientW=document.getElementById("mycontain_box").offsetWidth;
            var column= parseInt(clientW/(160+clientW*0.05));
            var xlength=[];
            var top=15;
            var imgs=document.getElementsByClassName('imgbox');
            for(var xindex=0;xindex<imgs.length;xindex++){
                if(xindex<column){
                    xlength.push(imgs[xindex].offsetHeight);
                    imgs[xindex].style.top='0px';
                    imgs[xindex].style.left=(clientW*0.05+160)*xindex+15+'px';
                }
                else{
                    var min=xlength[0];
                    max=xlength[0];
                    var index=0;
                    for(var j=0;j<xlength.length;j++){
                        if(min>xlength[j]){
                            min=xlength[j];
                            index=j;
                        }
                        
                    }
                    imgs[xindex].style.top = min+top+'px';
                    imgs[xindex].style.left = imgs[index].offsetLeft+'px';
                    xlength[index]= imgs[xindex].clientHeight+top+xlength[index];
                }
            }
            var max=0;
            for(var i=0;i<xlength.length;i++){
                if(max<xlength[i]){
                    max=xlength[i];
                }
            }
            document.getElementById('mycontain_box').style.height=max+80+'px';
        },
        pic(){
            for(var xindex=0;xindex<document.getElementsByClassName('imgbox').length;xindex++){
            var img=document.getElementById('wtf_img'+xindex);
            var imgbox=document.getElementById('imgbox'+xindex);
            var imgWidth = 160;
            var imgHeight = parseInt(img.naturalHeight/parseInt(img.naturalWidth/imgWidth))+'px';
            img.style.width=imgWidth;
            img.style.height=imgHeight;
            imgbox.style.width=imgWidth;
            imgbox.style.height=imgHeight+100+'px';
            }
            this.changeP();
        }
    },
    created(){
        window.changeP=this.changeP;
        window.pic=this.pic;
    },
    mounted(){
        setTimeout(()=>{
            this.pic()
        },10)
        
    },
    beforeDestroy(){
        window.onresize = null;
    },
    props:['waterfall_imgs'],
    
}


/*页面尺寸改变时重新加载图片 */
window.onresize = function () {
    changeP();
}

</script>
<style>
    *
    {
        margin: 0px;
        padding: 0px;        
    }
    .imgbox
    {
        width: 160px;
        background: white;
        display: inline-block;
        overflow: hidden;
        position: absolute;
        border-radius: 15px;
        box-shadow: 0 15px 30px rgba(206, 206, 206, 0.1);
        transition: 0.1s ease-in-out;
    }
    .imgbox img
    {
        z-index: -1000;
    }
    .contain_box
    {
        position: relative;
        width: 90%;
        margin: 15px 0 0 5%;
        border: 0;
    }
    .mytitle
    {
        margin-left: 10px;
    }
    .myavatar
    {
        margin-top: 8px;
        width: 30px;
        height: 30px;
        border-radius: 50%;
        margin-left: 5px;
    }
    .like_share
    {
        margin-top: 5px;
        display: block;
    }
    .Nname
    {
        position:absolute;
        left: 45px;
        bottom:22px;
        color: rgb(201, 201, 201);
        font-size: 10px;
    }
    .Star
    {
        position:absolute;
        left: 45px;
        bottom:2px;
        font-size: 10px;
    }
    .fontSize
    {
        font-size: 8px;
        color: rgb(201, 201, 201);
    }
    .water_icon
    {
        fill: rgb(201, 201, 201);
        width: 15px;
        height: 15px;
        margin-left: 5px;
    }
</style>