
import Vue from 'vue'
import Vuex from 'vuex'
import playlist from './module/playlist'
import users from './module/users'
Vue.use(Vuex)

export default new Vuex.Store({
    state:{
        
    },
    mutations:{

    },
    actions:{

    },
    getters:{

    },
    modules:{
        playlist,
        users
    }
})