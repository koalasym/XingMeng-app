const state={
    list:[],
    playsource:null,
    playstate:0,
    song_state:0,
}
const mutations={
    addList(state,data){
        const result = state.list.find(mylist=>mylist.data.id===data.data.id)
        if(!result){
            state.list.unshift(data);
        }
    },
    playnow(state,data){
        state.playsource=data.data;
    },
    setPlaystate(state,playstate){
        state.playstate=playstate;
    },
    changeSong(state,data){
        const result = state.list.find(mylist=>mylist.data.id===data)
        if(result.data.id===state.playsource.id){
            state.song_state=0;
        }else{
            var index = state.list.indexOf(result);
            var tmp = state.list[index];
            state.list[index] = state.list[0]
            state.list[0] = tmp;
            state.playsource = result.data;
            state.song_state=1;
        }
    },
    deleteList(state){
        state.list.shift();
    },
    clearallList(state){
        state.list = [];
    },
    delete_song(state,data){
        var index = state.list.indexOf(data);
        state.list.splice(index,1);
        if(state.playsource.id==data.data.id){
            if(state.list!='')
            state.playsource = state.list[0].data;
        }
    }
}
const actions={

}
const getters={

}
export default{
    namespaced:true,
    state,
    mutations,
    actions,
    getters
}