const state={
    userdata:null,
}
const mutations={
    
}
const actions={

}
const getters={

}
export default{
    namespaced:true,
    state,
    mutations,
    actions,
    getters
}