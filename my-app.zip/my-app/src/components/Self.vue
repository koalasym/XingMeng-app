<template>
  <div id="tot_body">
    <div v-if="show" id="slide_headpart">
      <img id="slide_head" :src="myuser.avatar">{{myuser.username}}
    </div>
    <div id="top_container">
      <div v-if="show" class="showbox">
        <div id="head_box">
          <img id="my_avatar" :src="myuser.avatar">
          <span id="myName">{{myuser.username}}</span>
          <span id="myPosition">{{myuser.address}}</span>
        </div>
        <ul id="detail_box">
          <li class="detail_item">
            <span class="detail_item_title">星球帖子</span>
            <span class="detail_item_content">{{myuser.post}}</span>
          </li>
          <li class="detail_item">
            <span class="detail_item_title">关注</span>
            <span class="detail_item_content">{{myuser.follow}}</span>
          </li>
          <li class="detail_item">
            <span class="detail_item_title">粉丝</span>
            <span class="detail_item_content">{{myuser.fans}}</span>
          </li>
        </ul>
      </div>
      <div v-if="!show" class="login_box showbox">
        <div id="login_title">当前未登录</div>
        <router-link to="./Login" id="login_button" tag="button">请登录</router-link>
      </div>
      <img src="@/assets/self/self_more.png" id="more_icon">
    </div>
    <div id="bottom_container">
      <div id="sleep_box">
        <div id="sleep_box_title">
          <img class="report_icon" src="@/assets/self/report.png">
          近期睡眠报告
        </div>
        <div id="check_more">
          查看更多->
        </div>
        <ul id="sleep_box_content">
          <li class="sleep_box_content_detail">
            <div class="sleep_box_content_detail_title">
              <img class="report_icon" src="@/assets/self/duration.png">
              <span>深度时长</span>
            </div>
            <span class="sleep_box_content_detail_content">2.5h</span>
          </li>
          <li class="sleep_box_content_detail">
            <div class="sleep_box_content_detail_title">
              <img class="report_icon" src="@/assets/self/quantity.png">
              <span>睡眠质量</span>
            </div>
            <span class="sleep_box_content_detail_content">87分</span>
          </li>
          <li class="sleep_box_content_detail">
            <div class="sleep_box_content_detail_title">
              <img class="report_icon" src="@/assets/self/sleep.png">
              <span>睡眠时长</span>
            </div>
            <span class="sleep_box_content_detail_content">7h</span>
          </li>
        </ul>
      </div>
      <ul class="setting">
        <li class='setting_item vip'><img src="@/assets/self/vip.png" class="report_icon icon_pos">成为会员<span class="setting_content">-诚心严选精致音频</span></li>
        <li class='setting_item'><img src="@/assets/self/history.png" class="report_icon icon_pos">播放历史<span class="setting_content">></span></li>
        <li class='setting_item'><img src="@/assets/self/like.png" class="report_icon icon_pos">喜欢列表<span class="setting_content">></span></li>
        <li class='setting_item'><img src="@/assets/self/collo.png" class="report_icon icon_pos">我的收藏<span class="setting_content">></span></li>
        <li class='setting_item'><img src="@/assets/self/user.png" class="report_icon icon_pos">账号信息<span class="setting_content">></span></li>
      </ul>
      <ul class="setting">
        <li class='setting_item'><img src="@/assets/self/modal.png" class="report_icon icon_pos">我的奖牌<span class="setting_content">></span></li>
        <li class='setting_item'><img src="@/assets/self/quan.png" class="report_icon icon_pos">我的礼券<span class="setting_content">></span></li>
        <li class='setting_item'><img src="@/assets/self/shop.png" class="report_icon icon_pos">商品购买<span class="setting_content">></span></li>
        <li class='setting_item'><img src="@/assets/self/test.png" class="report_icon icon_pos">我的测评<span class="setting_content">></span></li>
        <li class='setting_item'><img src="@/assets/self/free.png" class="report_icon icon_pos">免广告权益<span class="setting_content">></span></li>
      </ul>
      <ul class="setting">
        <li class='setting_item'><img src="@/assets/self/feedback.png" class="report_icon icon_pos">帮助与反馈<span class="setting_content">></span></li>
        <li class='setting_item'><img src="@/assets/self/update.png" class="report_icon icon_pos">版本更新<span class="setting_content">></span></li>
        <li class='setting_item'><img src="@/assets/self/set.png" class="report_icon icon_pos">系统设置<span class="setting_content">></span></li>
        <li class='setting_item'><img src="@/assets/self/about.png" class="report_icon icon_pos">关于星梦<span class="setting_content">></span></li>
      </ul>
    </div>
    <div id="last_one"></div>
  </div>
</template>
<script>
export default {
  name: 'Self',
  data(){
    return{
      myuser:null,
      show:false
    }
  },
  methods:{
    getscroll(){
      var headpart = document.getElementById("slide_headpart");
      var offsettop = document.documentElement.scrollTop;
      if(offsettop<=210)
      headpart.style.opacity = Math.round(offsettop/2)+'%';
    }
  },
  mounted(){
    if(this.myuser!=null){
      window.addEventListener('scroll',this.getscroll, true);
    }
  },
  beforeDestroy(){
    window.removeEventListener('scroll',this.getscroll,true);
  },
  created(){
    this.myuser=JSON.parse(window.localStorage.getItem('myuser'));
    if(this.myuser!=null){
      this.show=true;
    }
  }
}
</script>
<style scoped>
#tot_body
{
  width: 100vw;
  height: 100vh;
}
#top_container
{
  width: 100vw;
  height: 40%;
  background: linear-gradient(-45deg,#a8c0ff,#c5baf8);
}
.login_box{
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}
#login_title{
  font-size: 25px;
  font-family: "濑户字体简体";
  color: white;
}
#login_button{
  width: 100px;
  border-radius: 5px;
  line-height: 30px;
  font-size: 20px;
  color: white;
  font-family: "濑户字体简体";
  border: none;
  background: #4A00E0;
  margin-top: 20px;
}
.showbox
{
  width: 100vw;
  height: 100%;
}
#head_box{
  height: 60%;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
}
#my_avatar
{
  width: 55px;
  height: 55px;
  border-radius:25px;
}
#myName{
  margin-top:5px;
  font-size: 20px;
  font-family: "濑户字体简体";
  color: white;
  font-weight: bold;
  letter-spacing: 2px;
}
#myPosition{
  margin-top: 5px;
  font-size: 13px;
  font-family: "濑户字体简体";
  color: black;
  font-weight: bold;
  letter-spacing: 1px;
}
#detail_box{
  height: 75px;
  width: 90%;
  margin-left: 2%;
  display: flex;
  list-style: none;
  justify-content: space-around;
}
.detail_item{
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}
.detail_item_title{
  font-size: 16px;
  color: white;
  font-family: "濑户字体简体";
  font-weight: bold;
}
.detail_item_content{
  margin-top:15px;
  font-size: 14px;
  color:black;
  font-family: "濑户字体简体";
  font-weight: bold;
}
#more_icon{
  height: 35px;
  width: 35px;
  position: fixed;
  top: 10px;
  right: 10px;
  z-index: 1;
}
#bottom_container{
  width: 100%;
  position: relative;
  top: -25px;
  border-radius: 25px;
  background: white;
  padding-top: 20px;
}
#sleep_box{
  height:120px;
  width: 80%;
  margin-left: 10%;
  border-radius: 25px;
  background: linear-gradient(45deg,#5f4b70,#8c7fa5);
}
.report_icon{
  height: 25px;
  width: 25px;
}
#sleep_box_title{
  color:white;
  font-family: "濑户字体简体";
  display: flex;
  align-items: center;
  justify-content: center;
  height: 40px;
  font-weight: bold;
}
#check_more{
  color: white;
  position: absolute;
  right: 13%;
  top: 35px;
  font-family: "濑户字体简体";
  font-size: 10px;
}
#sleep_box_content{
  margin-top:10px;
  list-style: none;
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: space-around;
  font-weight: bold;
}
.sleep_box_content_detail_title{
  display: flex;
  align-items: center;
  font-family: "濑户字体简体";
  color:white;
  font-size: 13px;
}
.sleep_box_content_detail_content{
  font-size:15px;
  color: white;
  font-family: "濑户字体简体";
  margin-top: 5px;
}
.sleep_box_content_detail{
  display: flex;
  flex-direction: column;
  align-items: center;
}

.setting{
  width: 80%;
  margin:15px 0 0 10%;
  list-style: none;
  background: rgb(247, 247, 247);
  border-radius: 25px;
}
.setting_item{
  line-height: 50px;
  padding-left: 20px;
  font-size: 16px;
  font-family: "濑户字体简体";
  display: flex;
  align-items: center;
  color: rgb(121, 121, 121);
}
.vip{
  background: linear-gradient(45deg,#f3d696,#f77162);
  border-top-left-radius: 25px;
  border-top-right-radius: 25px;
  color: #804d00;
}
.icon_pos{
  margin-right: 10px;
}
.setting_content{
  position: absolute;
  right:14%;
}
#last_one{
  height: 100px;
}

#slide_headpart{
  position: fixed;
  height: 50px;
  width: 100%;
  display: flex;
  align-items: center;
  color: white;
  font-family: "濑户字体简体";
  font-size: 18px;
  background: linear-gradient(-45deg,#a8c0ff,#c5baf8);
  z-index: 1;
  opacity: 0%;
  border-bottom-left-radius: 25px;
  border-bottom-right-radius: 25px;
}
#slide_head{
  height: 35px;
  width: 35px;
  border-radius: 25px;
  margin-left: 15px;
  margin-right: 15px;
}
</style>
