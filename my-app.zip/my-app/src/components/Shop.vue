<template>
  <div>
    <div id="tot_part">
    </div>
    <div id="head_container">
      <div id="mytitle" class="shop_title">Hi! 当前未登录</div>
      <div v-if="show"><img :src=myuser.avatar id="myhead"></div>
      <slide :imgs=imgs id="myslide"></slide>
    </div>
    <div id="middle_container">
      <ul id="sp_list">
        <li class="list_detail" v-for="(icon,index) in myshopicons" :key="index">
          <img class='shop_icon' :src=icon.src>
          <div class="myfont">{{icon.title}}</div>
        </li>
      </ul>
    </div>
    <div id="bottom_container">
      <div id="more_title">猜你喜欢</div>
      <div class="shop_item" v-for="(item,index) in myitems" :key="index">
        <div class="img_box" :style="{'background':item.color}">
            <img class="item_img" :src="item.src">
        </div>
        <span>{{item.title}}</span>
      </div>
    </div>
  </div>
</template>
<script>
import Slide from './Slide.vue';
export default {
  name: 'Shop',
  data(){
    return{
      imgs: [
        {src:'https://img.alicdn.com/imgextra/i3/858470175/O1CN01pGcGJf1DAC0L4BFd5_!!0-saturn_solar.jpg_468x468q75.jpg_.webp'},
        {src:'https://img.alicdn.com/imgextra/i4/1383590078/O1CN01qW0qML1CRlZCiElOL_!!0-saturn_solar.jpg_468x468q75.jpg_.webp'},
        {src:'https://img.alicdn.com/imgextra/i4/858470175/O1CN01Nu39zU1DAC2I3uGVI_!!0-saturn_solar.jpg_468x468q75.jpg_.webp'},
        {src:'https://img.alicdn.com/imgextra/i2/1464190144/O1CN01BLkbw61CvzkfSFOTH_!!0-saturn_solar.jpg_468x468q75.jpg_.webp'},
        {src:'https://img.alicdn.com/imgextra/i4/1917440194/O1CN01Y4u0Dy1DItXbQzSh1_!!0-saturn_solar.jpg_468x468q75.jpg_.webp'},
      ],
      myshopicons:[
        {src:require('@/assets/shop/discount.png'),title:"优惠特价"},
        {src:require('@/assets/shop/keep.png'),title:"止鼾精品"},
        {src:require('@/assets/shop/hot.png'),title:"热销商品"},
        {src:require('@/assets/shop/more.png'),title:"更多精品"},
      ],
      myitems:[
        {src:require('@/assets/shop/item1.png'),title:'1',color:'#f1fde7'},
        {src:require('@/assets/shop/item2.png'),title:'2',color:'#f1f0ff'},
        {src:require('@/assets/shop/item3.png'),title:'3',color:'#ffefef'},
        {src:require('@/assets/shop/item4.png'),title:'4',color:'#f1fde7'},
      ],
      show:false,
      myuser:null
    }
  },
  components:{
    Slide
  },
  created(){
    this.myuser=JSON.parse(window.localStorage.getItem('myuser'));
    if(this.myuser!=null){
      this.show=true;
    }   
  },
  mounted(){
    if(this.myuser!=null){
      document.getElementById("mytitle").innerHTML='Hi！'+this.myuser.username;
    }
  }
}
</script>
<style scoped>
  *
  {
    margin: 0;
    padding: 0;
  }
  #tot_part
  {
    position: fixed;
    width: 100%;
    height: 100%;
    background: #fcfff5;
    background-size:100% 100%;
  }
  #head_container
  {
    width: 100%;
    height: 100%;
  }
  .shop_title
  {
    font-size:20px;
    position:absolute;
    top:5%;
    left:10%;
    color:gray;
    font-family:"微软雅黑";
    font-weight:bold;
    transition: 0.5s ease-in-out;
  }
  #login_button{
    width: 100px;
    border-radius: 5px;
    line-height: 30px;
    font-size: 20px;
    color: white;
    font-family: "濑户字体简体";
    border: none;
    background: #4A00E0;
    margin-top: 20px;
  }
  .login_box{
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    position: absolute;
    top: 0px;
  }
  .showbox
  {
    width: 100vw;
    height: 100%;
  }
  #myhead
  {
    width: 50px;
    height: 50px;
    position: absolute;
    right: 10%;
    top:3%;
    border-radius: 25px;
  }
  #myslide
  {
    position: absolute;
    top: 80px;
    left: 5%;
    width: 90%;
  }
  #myslide img
  {
    width: 100%;
    height: 100%;
  }
  #login_title{
  font-size: 25px;
  font-family: "濑户字体简体";
  color: black;
  }

  #middle_container
  {
    position: absolute;
    top: 58%;
    width: 100%;
  }
  #sp_list
  {
    width: 80%;
    margin-left: 10%;
    display: flex;
    justify-content: space-around;
    align-items: center;
    list-style: none;
    background: linear-gradient(250deg, #f1fde7, #f1f0ff, #ffefef);
    background-size: 600% 600%;
    animation:bgTrans 5s ease-in-out infinite;
    overflow: hidden;
    border-radius:15px;
  }
  .list_detail
  {
    width: 20%;
    height: 60px;
    display: flex;
    align-items: center;
    flex-direction: column;
  }
  .myfont
  {
    margin-top: 8px;
    font-size:12px;
    color:gray;
    font-family: "微软雅黑";
    letter-spacing: 2px;
    font-weight: bold;
  }
  .shop_icon
  {
    margin-top: 5px;
    width: 25px;
    height: 25px;
  }

  #bottom_container
  {
    position: absolute;
    top:70%;
    width: 100%;

  }
  #more_title{
    font-family: "微软雅黑";
    font-size:18px;
    font-weight: bold;
    color:gray;
    letter-spacing: 1px;
    position: absolute;
    left: 10%;
  }
  .shop_item
  {
    width: 80%;
    height: 200px;
    margin: 10%;
    background: rgb(255, 255, 255);
    border-radius:25px;
  }
  .item_img
  {
    height: 125px;
    width: auto;
  }
  .img_box
  {
    text-align: center;
    border-radius: 15px;
    background: rgb(241, 255, 249);
  }
  @keyframes bgTrans {
    0%{background-position:0% 71%}
    50%{background-position:100% 30%}
    100%{background-position:0% 71%}
  }
</style>
