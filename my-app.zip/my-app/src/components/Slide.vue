<template>
  <div class='slide_nav'>
      <img class='slide_img'  v-for="(img,Index) in imgs" :key="Index" :src="img.src" v-show="Index===slideIndex">
      <ul>
        <li @click="upSet"><svg t="1635658078037" class="slide_icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="7920" width="200" height="200"><path d="M473.6 490.666667L789.333333 170.666667 853.333333 230.4l-260.266666 260.266667 260.266666 260.266666-64 59.733334-315.733333-320z m-302.933333 0L490.666667 170.666667l59.733333 59.733333-260.266667 260.266667 260.266667 260.266666-59.733333 59.733334L170.666667 490.666667z" fill="#444444" p-id="7921"></path></svg></li>
        <li v-for="(img,imgIndex) in imgs" :key="imgIndex" :class="slideIndex===imgIndex?'li_active':''">{{imgIndex+1}}</li>
        <li @click="downSet"><svg t="1635658333170" class="slide_icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="8067" width="200" height="200"><path d="M550.4 490.666667L230.4 170.666667 170.666667 230.4l260.266666 260.266667L170.666667 750.933333 230.4 810.666667l320-320z m298.666667 0L533.333333 170.666667 469.333333 230.4l260.266667 260.266667-260.266667 260.266666 59.733334 59.733334 320-320z" fill="#444444" p-id="8068"></path></svg></li>
      </ul>
  </div>
</template>
<script>
export default {
  name: 'Slide',
  data(){
    return{
    slideIndex: 0,
    Slidespeed: 3000,
    timer:null,
    }
  },
  methods:{
    RunTime(){
      this.timer=setInterval(()=>{
        if(this.slideIndex==(this.imgs.length-1)){
          this.slideIndex = 0;
        }
        else{
          this.slideIndex++;
        }
      },this.Slidespeed)
    },
    upSet(){
      window.clearInterval(this.timer);
      this.timer=null;
      if(this.slideIndex==0)
        this.slideIndex=this.imgs.length-1;
      else
        this.slideIndex--;
      this.RunTime();
    },
    downSet(){
      window.clearInterval(this.timer);
      this.timer=null;
      if(this.slideIndex==(this.imgs.length-1))
        this.slideIndex=0;
      else
        this.slideIndex++;
      this.RunTime();
    },
  },
  created(){
    this.RunTime();
  },
  props:['imgs']
}
</script>
<style scoped>
  .slide_img
  {
    width: 80%;
    height: auto;
    margin: 15px 0 0 10%;
    border-radius: 10px;
    transition: 1s ease-in-out;
  }
  .slide_nav ul
  {
    position: relative;
    text-align: right;
    bottom:40px;
    height: 20px;
    margin-right: 15%;
  }
  .slide_nav li
  {
    display: inline-block;
    height: 15px;
    width: 15px;
    font-size: 10px;
    background-color: rgb(226, 226, 226);
    color: black;
    margin-left: 5px;
    transition: 0.5s ease-in-out;
    text-align: center;
  }
  .slide_nav .li_active
  {
    background-color: black;
    color: rgb(226, 226, 226);
    height: 15px;
    width: 15px;
  }
  .slide_icon
  {
    height: 10px;
    width: 10px;
  }
</style>
