import Vue from 'vue'
import Router from 'vue-router'
import Index from '@/components/Index'
import Self from '@/components/Self'
import Shop from '@/components/Shop'
import Sleep from '@/components/Sleep'
import Star from '@/components/Star'
import Slide from '@/components/Slide'
import Waterfall from '@/components/Waterfall'
import Detail from '@/components/Detail'
import Playlist from '@/components/Playlist'
import Login from '@/components/Login'
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      redirect: '/Index',

      meta:{
        keepAlive:1
      }
    },
    {
      path: '/index',
      component: Index,
      meta:{
        keepAlive:1
      }
    },
    {
      path: '/self',
      component: Self,
      meta:{
        keepAlive:1
      }
    },
    {
      path: '/shop',
      component: Shop,
      meta:{
        keepAlive:1
      }
    },
    {
      path: '/star',
      component: Star,
      meta:{
        keepAlive:1
      }
    },
    {
      path: '/sleep',
      component: Sleep,
      meta:{
        keepAlive:1
      }
    },
    {
      path: '/slide',
      component: Slide,
      meta:{
        keepAlive:1
      }
    },
    {
      path: '/waterfall',
      component: Waterfall,
      meta:{
        keepAlive:1
      }
    },
    {
      path: '/detail/:id',
      component: Detail
    },
    {
      path: '/playlist',
      component: Playlist
    },
    {
      path: '/login',
      component: Login
    }
  ]
})
