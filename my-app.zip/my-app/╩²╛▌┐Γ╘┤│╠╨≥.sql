create database mydatabase;
drop table if exists waterfalls;
create table waterfalls(
	id int auto_increment primary key,
    src varchar(500),
    mylike varchar(10),
    share varchar(10),
    title varchar(25),
    avatar varchar(500),
    Nname varchar(10),
    Star varchar(10)
) ;
insert into waterfalls(src,mylike,share,title,avatar,Nname,Star) values('https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fup.enterdesk.com%2Fedpic%2Ff6%2Fc9%2Ff6%2Ff6c9f647a533782026c0609ac5d550df.jpg&refer=http%3A%2F%2Fup.enterdesk.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1642938556&t=3dd9e769b8c71364647148caf25c5a9c','3k+','1k+','简朴时刻','https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fup.enterdesk.com%2F2021%2Fedpic%2F0b%2F17%2F04%2F0b1704a9741f4e7ddd07939877dd3590_1.jpg&refer=http%3A%2F%2Fup.enterdesk.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1642938957&t=8a75e2f53e324ccfbc25d3300831743a','老家の诱惑','飞翔星球'),
('https://images.pexels.com/photos/2363814/pexels-photo-2363814.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260','2k+','1k+','魔幻空间','http://scimg.jianbihuadq.com/202011/2020112318291714.jpg','吾身伴弧','火火星球'),
('https://images.pexels.com/photos/2033981/pexels-photo-2033981.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260','1k+','1k+','舒心宁夏','http://scimg.jianbihuadq.com/202008/20200812214541114.jpg','墨鱼','自由星球'),
('https://cdn.pixabay.com/photo/2021/11/15/05/52/red-fox-6796430_960_720.jpg','2k+','1k+','聆听山音','http://scimg.jianbihuadq.com/touxiang/202004/202004012005566.jpg','风中欢聚','落寞星球');

select * from waterfalls;

drop table if exists Details;
create table Details(
	id int auto_increment primary key,
    mp3or4 varchar(250),
    content varchar(50),
    tags varchar(100),
    heads varchar(100)
);
insert into Details(mp3or4,content,tags,heads) values
('1.mp3','装傻这事，如果干的好，就叫大智若愚；木纳这事，如果干的好，就叫深沉。','深沉主义者,精致生活,山间生活,逍遥快活,自然至上',''),
('2.mp3','要么放弃，要么彻底。既然我做不到彻底，那么我就应该放弃。在一个不懂的年纪，我凭什么假装深沉。','深沉主义者,懂得生活,逍遥快活,假装深沉',''),
('3.mp3','像我这样庸俗的人，从不喜欢装深沉，怎么偶尔听到老歌时，忽然也恍了神。','深沉主义者,老歌,深沉,逍遥快活',''),
('4.mp3','在明亮的白昼要像雄狼一样深沉细心！在黑暗的夜里，要像乌鸦一样，有坚强的忍耐力。','深沉主义者,细心,忍耐,孤高','');
select * from details;

drop table if exists users;
create table users(
	userid int auto_increment primary key,
    accountid varchar(18),
    password varchar(20),
    username varchar(20),
    address varchar(20),
    post varchar(10),
    follow varchar(10),
    fans varchar(10),
    avatar varchar(1000)
);
insert into users(accountid,password,username,address,post,follow,fans,avatar) values
('19858159655','mypassword','Rover浪迹','中国·福建','1.1w','1005','2.9w','https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fup.enterdesk.com%2F2021%2Fedpic_source%2Fed%2F4a%2F28%2Fed4a2866314a54ee84bc9e9e15ec3b4c_10.jpg&refer=http%3A%2F%2Fup.enterdesk.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1644058263&t=faec94a7ffb4dc56604e3a5a9f0af59a');
select * from users;