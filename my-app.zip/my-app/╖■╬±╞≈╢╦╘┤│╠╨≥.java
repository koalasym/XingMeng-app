package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONException;

import org.json.JSONArray;
import org.json.JSONObject;

import com.mysql.cj.jdbc.result.ResultSetMetaData;
import com.mysql.cj.protocol.Resultset;

public class testconnection extends HttpServlet {
	Connection conn = null;
	Statement stat = null;
	ResultSet rs = null;
	StringBuilder sql=null;
	/**
	 * Constructor of the object.
	 */
	public testconnection() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		response.setHeader("Access-Control-Allow-Origin","*");
		response.setContentType("application/json;charset=utf-8");
		response.setCharacterEncoding("UTF-8");
		String id = (request.getParameter("id"));	
		String type = (request.getParameter("type"));
		try {
			stat = conn.createStatement();
			if((type==null)){
				if(null==(request.getParameter("id"))){
					sql=new StringBuilder("select * from waterfalls a join details b using(id)");
				}else{
					sql=new StringBuilder("select * from waterfalls a join details b using(id) where a.id =");
					sql.append(id);
				};
				rs=stat.executeQuery(sql.toString());
			}else if(type.equals("2")){
				sql = new StringBuilder("select * from users");
				rs=stat.executeQuery(sql.toString());
			}else if(type.equals("3")){
				sql = new StringBuilder("insert into users(accountid,password,username,address,post,follow,fans,avatar) values('");
				sql.append(request.getParameter("accountid"));
				sql.append("','");
				sql.append(request.getParameter("password"));
				sql.append("','");
				sql.append(request.getParameter("username"));
				sql.append("','");
				sql.append(request.getParameter("address"));
				sql.append("','");
				sql.append(request.getParameter("post"));
				sql.append("','");
				sql.append(request.getParameter("follow"));
				sql.append("','");
				sql.append(request.getParameter("fans"));
				sql.append("','");
				sql.append(request.getParameter("avatar"));
				sql.append("')");
				stat.execute(sql.toString());
			}
			JSONArray array = new JSONArray();
			array= resultSetToJsonArray(rs);
			out.print(array);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	};
	public static JSONArray resultSetToJsonArray(ResultSet rs) throws SQLException , JSONException
	{
		JSONArray array = new JSONArray();
		ResultSetMetaData metadata = (ResultSetMetaData) rs.getMetaData();
		int columnCount = metadata.getColumnCount();
		
		while (rs.next()){
			JSONObject jsonObj = new JSONObject();
			for(int i=1;i<= columnCount;i++){
				String columnName = metadata.getColumnLabel(i);
				String value = rs.getString(columnName);
				jsonObj.put(columnName, value);
			}
			array.put(jsonObj);
		}
		return array;
		
	}
	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the POST method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/mydatabase?characterEncoding=UTF-8&useOldAliasMetadataBehavior=true&serverTimezone=GMT";
			try {
				conn = DriverManager.getConnection(url,"root","sql2008");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.print("Test!");
		
	}

}
